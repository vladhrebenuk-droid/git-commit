# VERDENA

Dark anonymous messenger + relay system.

## Modules
- Telegram bot (mobile)
- Web panel (panel)
- Core logic (core)
- Data storage (data)

## Features
- Anonymous chats
- User ID system
- Relay messaging
- Owner panel
- Requests system

## Start (Termux)

bash mobile/start_phone.sh
