VERDENA gothic safe build
1. unpack archive
2. copy folder to Termux home
3. create config.env from config.env.example
4. run bash mobile/install_phone.sh
5. run bash mobile/start_phone.sh
