
import os
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, session
from core.store import get_requests, update_request, get_users, create_request

BASE = Path(__file__).resolve().parents[1]
OWNER_PASSWORD = os.getenv("OWNER_PASSWORD", "qazwsx")

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = "verdena-gothic-safe"

@app.context_processor
def nav():
    return {"nav":[
        ("dashboard","Dashboard"),
        ("request_form","Оставить заявку"),
        ("requests_page","Requests"),
        ("users_page","Users"),
        ("manual","Manual"),
        ("settings","Owner"),
    ]}

@app.route("/")
def dashboard():
    items = get_requests()
    users = get_users()
    stats = {
        "requests": len(items),
        "new": len([x for x in items if x.get("status") == "new"]),
        "in_progress": len([x for x in items if x.get("status") == "in_progress"]),
        "closed": len([x for x in items if x.get("status") == "closed"]),
        "users": len(users),
    }
    return render_template("dashboard.html", stats=stats, latest=items[:5])

@app.route("/request-form", methods=["GET","POST"])
def request_form():
    if request.method == "POST":
        item = create_request(
            name=request.form.get("name","").strip() or "Без имени",
            message=request.form.get("message","").strip(),
            contact_type=request.form.get("contact_type","").strip(),
            contact_value=request.form.get("contact_value","").strip(),
            user_id=None
        )
        flash(f"Заявка #{item['id']} отправлена.", "success")
        return redirect(url_for("request_form"))
    return render_template("request_form.html")

@app.route("/requests")
def requests_page():
    return render_template("requests.html", requests=get_requests())

@app.route("/request/<int:rid>/status", methods=["POST"])
def request_status(rid):
    update_request(rid, request.form.get("status","new"), request.form.get("owner_note","").strip())
    flash(f"Заявка #{rid} обновлена.", "success")
    return redirect(url_for("requests_page"))

@app.route("/users")
def users_page():
    return render_template("users.html", users=get_users())

@app.route("/manual")
def manual():
    return render_template("manual.html")

@app.route("/owner-login", methods=["GET","POST"])
def owner_login():
    if request.method == "POST":
        password = request.form.get("password","").strip()
        if password == OWNER_PASSWORD:
            session["owner_ok"] = True
            flash("Режим владельца открыт.", "success")
            return redirect(url_for("settings"))
        flash("Неверный пароль.")
    return render_template("owner_login.html")

def owner_required():
    return session.get("owner_ok") is True

@app.route("/settings")
def settings():
    if not owner_required():
        return redirect(url_for("owner_login"))
    return render_template("settings.html")

if __name__ == "__main__":
    port = int(os.getenv("PANEL_PORT", "8080"))
    app.run(host="0.0.0.0", port=port, debug=False)
