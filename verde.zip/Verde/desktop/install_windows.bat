@echo off
py -m pip install --upgrade pip
py -m pip install python-telegram-bot flask
echo Done.
