@echo off
cd /d %~dp0..
for /f "tokens=* delims=" %%a in (config.env) do set %%a
start py core\bot.py
start py panel\app.py
