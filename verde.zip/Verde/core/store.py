
import json
import secrets
import string
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
USERS = DATA / "users.json"
REQUESTS = DATA / "requests.json"

def _load(path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def _save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")

def make_code():
    alphabet = string.ascii_uppercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(6))

def get_users():
    return _load(USERS, [])

def save_users(users):
    _save(USERS, users)

def get_requests():
    return _load(REQUESTS, [])

def save_requests(reqs):
    _save(REQUESTS, reqs)

def get_or_create_user(tg_id, display_name):
    users = get_users()
    for u in users:
        if u.get("id") == tg_id:
            u["name"] = display_name or u.get("name") or "User"
            save_users(users)
            return u
    code = make_code()
    user = {"id": tg_id, "name": display_name or "User", "invite_code": code, "partner_id": None, "favorite": False}
    users.append(user)
    save_users(users)
    return user

def get_user(tg_id):
    for u in get_users():
        if u.get("id") == tg_id:
            return u
    return None

def get_user_by_code(code):
    code = (code or "").upper()
    for u in get_users():
        if u.get("invite_code") == code:
            return u
    return None

def set_partner(a_id, b_id):
    users = get_users()
    for u in users:
        if u.get("id") == a_id:
            u["partner_id"] = b_id
    save_users(users)

def clear_pair(a_id, b_id=None):
    users = get_users()
    for u in users:
        if u.get("id") == a_id or (b_id is not None and u.get("id") == b_id):
            u["partner_id"] = None
    save_users(users)

def create_request(name, message, contact_type, contact_value, user_id=None):
    reqs = get_requests()
    rid = max([x.get("id", 0) for x in reqs], default=0) + 1
    item = {
        "id": rid,
        "user_id": user_id,
        "name": name,
        "message": message,
        "contact_type": contact_type,
        "contact_value": contact_value,
        "status": "new",
        "owner_note": "",
        "created_at": __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    reqs.insert(0, item)
    save_requests(reqs)
    return item

def update_request(rid, status, owner_note):
    reqs = get_requests()
    for r in reqs:
        if r.get("id") == rid:
            r["status"] = status
            r["owner_note"] = owner_note
            break
    save_requests(reqs)
