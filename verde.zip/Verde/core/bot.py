
import os
from pathlib import Path
from telegram import ReplyKeyboardMarkup, Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters

from amidamaru import short_reply
from store import (
    get_or_create_user, get_user, get_user_by_code, set_partner, clear_pair,
    create_request
)

ROOT = Path(__file__).resolve().parents[1]
CFG = ROOT / "config.env"

def load_env(path):
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ[k.strip()] = v.strip()

load_env(CFG)
TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_PASSWORD = os.getenv("OWNER_PASSWORD", "qazwsx")
OWNER_CHAT_ID = os.getenv("OWNER_CHAT_ID", "")
PANEL_PORT = os.getenv("PANEL_PORT", "8080")

MENU = [
    ["✉ Начать диалог", "🔁 Сменить диалог"],
    ["🧹 Очистить чат", "📨 Оставить заявку"],
    ["🆔 Мой код", "ℹ Конфиденциальность"],
    ["⚔ Amidamaru"],
]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = get_or_create_user(update.effective_user.id, update.effective_user.full_name or "User")
    text = (
        "Добро пожаловать в VERDENA.\n"
        "Это relay-переписка по invite-кодам и форма заявок.\n\n"
        f"Твой код: {user['invite_code']}\n"
        "Нажми ✉ Начать диалог и отправь код другого пользователя.\n"
        f"Заявка: http://127.0.0.1:{PANEL_PORT}/request-form"
    )
    await update.message.reply_text(text, reply_markup=ReplyKeyboardMarkup(MENU, resize_keyboard=True))

async def owner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.args and context.args[0] == OWNER_PASSWORD:
        await update.message.reply_text("Режим владельца подтверждён.")
    else:
        await update.message.reply_text("Неверный пароль владельца.")

async def my_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = get_or_create_user(update.effective_user.id, update.effective_user.full_name or "User")
    await update.message.reply_text(f"Твой invite-код: {user['invite_code']}")

async def begin_dialog(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Отправь invite-код другого пользователя одним сообщением.")

async def switch_dialog(update: Update, context: ContextTypes.DEFAULT_TYPE):
    clear_pair(update.effective_user.id, None)
    await update.message.reply_text("Текущий диалог отключён. Теперь отправь новый invite-код.")

async def clear_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = get_user(update.effective_user.id)
    clear_pair(update.effective_user.id, user.get("partner_id") if user else None)
    await update.message.reply_text("Связь сброшена. Чат очищен внутри системы VERDENA.")

async def privacy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Собеседник не видит твой Telegram напрямую. Связь идёт через бота по invite-кодам.")

async def request_hint(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"Открой форму заявки:\nhttp://127.0.0.1:{PANEL_PORT}/request-form")

async def amidamaru(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Amidamaru рядом. Напиши задачу одним сообщением.")

async def relay_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    if not text:
        return

    menu_labels = {"✉ Начать диалог","🔁 Сменить диалог","🧹 Очистить чат","📨 Оставить заявку","🆔 Мой код","ℹ Конфиденциальность","⚔ Amidamaru"}
    if text in menu_labels:
        return

    user = get_or_create_user(update.effective_user.id, update.effective_user.full_name or "User")
    partner_id = user.get("partner_id")

    if not partner_id:
        candidate = get_user_by_code(text)
        if candidate and candidate.get("id") != user.get("id"):
            set_partner(user["id"], candidate["id"])
            set_partner(candidate["id"], user["id"])
            await update.message.reply_text("Диалог связан. Теперь можешь писать сообщение.")
            try:
                await context.bot.send_message(candidate["id"], "С тобой открыт relay-диалог в VERDENA. Можешь отвечать.")
            except Exception:
                pass
            return

        if len(text) > 8:
            item = create_request(
                name=update.effective_user.full_name or "User",
                message=text,
                contact_type="Telegram",
                contact_value=f"@{update.effective_user.username}" if update.effective_user.username else str(update.effective_user.id),
                user_id=update.effective_user.id
            )
            await update.message.reply_text(f"Код не найден. Я сохранил это как заявку #{item['id']}.")
            if OWNER_CHAT_ID:
                try:
                    await context.bot.send_message(int(OWNER_CHAT_ID), f"Новая заявка #{item['id']}\nОт: {item['name']}\n{item['message']}")
                except Exception:
                    pass
            return

        await update.message.reply_text("Код не найден. Отправь корректный invite-код или длинное сообщение как заявку.")
        return

    try:
        await context.bot.send_message(partner_id, f"📨 Анонимное сообщение:\n{text}")
        await update.message.reply_text("Сообщение отправлено.")
    except Exception:
        await update.message.reply_text("Не удалось доставить сообщение. Попробуй сменить диалог.")

def main():
    if not TOKEN:
        raise SystemExit("Укажи BOT_TOKEN в config.env.")
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("owner", owner))
    app.add_handler(MessageHandler(filters.Regex("^🆔 Мой код$"), my_code))
    app.add_handler(MessageHandler(filters.Regex("^✉ Начать диалог$"), begin_dialog))
    app.add_handler(MessageHandler(filters.Regex("^🔁 Сменить диалог$"), switch_dialog))
    app.add_handler(MessageHandler(filters.Regex("^🧹 Очистить чат$"), clear_chat))
    app.add_handler(MessageHandler(filters.Regex("^ℹ Конфиденциальность$"), privacy))
    app.add_handler(MessageHandler(filters.Regex("^📨 Оставить заявку$"), request_hint))
    app.add_handler(MessageHandler(filters.Regex("^⚔ Amidamaru$"), amidamaru))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, relay_text))
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
