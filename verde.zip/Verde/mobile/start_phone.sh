#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.." || exit 1
if [ ! -f config.env ]; then echo "Нет файла config.env"; exit 1; fi
set -a
. ./config.env
set +a
pkill -f "python core/bot.py" 2>/dev/null
pkill -f "PYTHONPATH=. python panel/app.py" 2>/dev/null
echo "Запускаю бота..."
python core/bot.py &
echo "Запускаю панель..."
python panel/app.py
