#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.." || exit 1
pkg update -y
pkg install -y python git nano
python -m pip install --upgrade pip
pip install python-telegram-bot flask
echo Done.
