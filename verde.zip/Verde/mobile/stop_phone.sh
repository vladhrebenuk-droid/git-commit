#!/data/data/com.termux/files/usr/bin/bash
pkill -f "python core/bot.py"
pkill -f "python panel/app.py"
echo "Stopped."
